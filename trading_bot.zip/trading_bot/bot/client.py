"""
client.py – Low-level Binance Futures Testnet REST client.

All API interaction lives here so the rest of the application
stays clean and decoupled from HTTP concerns.
"""

import hashlib
import hmac
import time
from decimal import Decimal
from typing import Any, Dict, Optional
from urllib.parse import urlencode

import requests

from .logging_config import get_logger

logger = get_logger("client")

BASE_URL = "https://testnet.binancefuture.com"
TIMEOUT = 10  # seconds


class BinanceAPIError(RuntimeError):
    """Raised when the Binance API returns an error response."""

    def __init__(self, code: int, message: str) -> None:
        self.code = code
        self.message = message
        super().__init__(f"Binance API error {code}: {message}")


class BinanceFuturesClient:
    """Thin wrapper around the Binance Futures Testnet REST API."""

    def __init__(self, api_key: str, api_secret: str) -> None:
        if not api_key or not api_secret:
            raise ValueError("API key and secret must not be empty.")
        self._api_key = api_key
        self._api_secret = api_secret.encode()
        self._session = requests.Session()
        self._session.headers.update(
            {
                "X-MBX-APIKEY": self._api_key,
                "Content-Type": "application/x-www-form-urlencoded",
            }
        )
        logger.info("BinanceFuturesClient initialised (testnet).")

    # ------------------------------------------------------------------ #
    # Internal helpers                                                     #
    # ------------------------------------------------------------------ #

    def _sign(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Append timestamp and HMAC-SHA256 signature to params."""
        params["timestamp"] = int(time.time() * 1000)
        query_string = urlencode(params)
        signature = hmac.new(
            self._api_secret, query_string.encode(), hashlib.sha256
        ).hexdigest()
        params["signature"] = signature
        return params

    def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        signed: bool = True,
    ) -> Dict[str, Any]:
        """Execute an HTTP request and return the parsed JSON body."""
        params = params or {}
        if signed:
            params = self._sign(params)

        url = BASE_URL + endpoint
        logger.info("REQUEST  %s %s | params=%s", method.upper(), url, params)

        try:
            response = self._session.request(
                method,
                url,
                params=params if method.upper() == "GET" else None,
                data=params if method.upper() == "POST" else None,
                timeout=TIMEOUT,
            )
        except requests.exceptions.ConnectionError as exc:
            logger.error("Network error: %s", exc)
            raise ConnectionError(f"Failed to connect to Binance Testnet: {exc}") from exc
        except requests.exceptions.Timeout:
            logger.error("Request timed out after %ss.", TIMEOUT)
            raise TimeoutError("Request to Binance Testnet timed out.")

        logger.info(
            "RESPONSE %s %s | status=%s body=%s",
            method.upper(),
            url,
            response.status_code,
            response.text[:500],
        )

        try:
            data = response.json()
        except ValueError:
            raise RuntimeError(f"Non-JSON response: {response.text[:200]}")

        if isinstance(data, dict) and "code" in data and data["code"] != 200:
            raise BinanceAPIError(data["code"], data.get("msg", "Unknown error"))

        return data

    # ------------------------------------------------------------------ #
    # Public API methods                                                   #
    # ------------------------------------------------------------------ #

    def get_exchange_info(self) -> Dict[str, Any]:
        """Fetch exchange info (symbol filters etc.)."""
        return self._request("GET", "/fapi/v1/exchangeInfo", signed=False)

    def get_account(self) -> Dict[str, Any]:
        """Fetch futures account information."""
        return self._request("GET", "/fapi/v2/account")

    def place_order(
        self,
        symbol: str,
        side: str,
        order_type: str,
        quantity: Decimal,
        price: Optional[Decimal] = None,
        stop_price: Optional[Decimal] = None,
        time_in_force: str = "GTC",
    ) -> Dict[str, Any]:
        """
        Place a futures order.

        Parameters
        ----------
        symbol       : Trading pair, e.g. 'BTCUSDT'
        side         : 'BUY' or 'SELL'
        order_type   : 'MARKET', 'LIMIT', 'STOP_MARKET', 'STOP_LIMIT'
        quantity     : Order quantity
        price        : Limit price (required for LIMIT / STOP_LIMIT)
        stop_price   : Trigger price (required for STOP_MARKET / STOP_LIMIT)
        time_in_force: 'GTC', 'IOC', 'FOK' (ignored for MARKET)
        """
        params: Dict[str, Any] = {
            "symbol": symbol,
            "side": side,
            "type": order_type,
            "quantity": str(quantity),
        }

        if order_type in {"LIMIT", "STOP_LIMIT"}:
            params["price"] = str(price)
            params["timeInForce"] = time_in_force

        if order_type in {"STOP_MARKET", "STOP_LIMIT"}:
            params["stopPrice"] = str(stop_price)

        logger.info(
            "Placing %s %s order | symbol=%s qty=%s price=%s stopPrice=%s",
            side,
            order_type,
            symbol,
            quantity,
            price,
            stop_price,
        )

        return self._request("POST", "/fapi/v1/order", params=params)
