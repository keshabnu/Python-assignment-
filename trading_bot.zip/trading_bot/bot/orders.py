"""
orders.py – Order placement logic.

Acts as the bridge between the CLI layer and the raw API client.
Handles validation, logging, and human-readable output formatting.
"""

from decimal import Decimal
from typing import Optional

from .client import BinanceFuturesClient, BinanceAPIError
from .validators import (
    validate_symbol,
    validate_side,
    validate_order_type,
    validate_quantity,
    validate_price,
    validate_stop_price,
    ValidationError,
)
from .logging_config import get_logger

logger = get_logger("orders")


def _format_response(response: dict) -> str:
    """Return a human-friendly summary of an order response."""
    lines = [
        "",
        "─" * 50,
        "  ORDER PLACED SUCCESSFULLY",
        "─" * 50,
        f"  Order ID   : {response.get('orderId', 'N/A')}",
        f"  Symbol     : {response.get('symbol', 'N/A')}",
        f"  Side       : {response.get('side', 'N/A')}",
        f"  Type       : {response.get('type', 'N/A')}",
        f"  Status     : {response.get('status', 'N/A')}",
        f"  Quantity   : {response.get('origQty', 'N/A')}",
        f"  Executed   : {response.get('executedQty', 'N/A')}",
    ]

    avg_price = response.get("avgPrice") or response.get("price")
    if avg_price and str(avg_price) != "0":
        lines.append(f"  Avg Price  : {avg_price}")

    stop_price = response.get("stopPrice")
    if stop_price and str(stop_price) != "0":
        lines.append(f"  Stop Price : {stop_price}")

    lines.append("─" * 50)
    return "\n".join(lines)


def place_order(
    client: BinanceFuturesClient,
    symbol: str,
    side: str,
    order_type: str,
    quantity: str,
    price: Optional[str] = None,
    stop_price: Optional[str] = None,
) -> dict:
    """
    Validate inputs, place an order, and print the result.

    Returns the raw API response dict on success.
    Raises ValidationError or BinanceAPIError on failure.
    """
    # --- Validate inputs ---
    symbol = validate_symbol(symbol)
    side = validate_side(side)
    order_type = validate_order_type(order_type)
    qty = validate_quantity(quantity)
    lmt_price = validate_price(price, order_type)
    stp_price = validate_stop_price(stop_price, order_type)

    # --- Print request summary ---
    print("\n" + "─" * 50)
    print("  ORDER REQUEST SUMMARY")
    print("─" * 50)
    print(f"  Symbol     : {symbol}")
    print(f"  Side       : {side}")
    print(f"  Type       : {order_type}")
    print(f"  Quantity   : {qty}")
    if lmt_price:
        print(f"  Limit Price: {lmt_price}")
    if stp_price:
        print(f"  Stop Price : {stp_price}")
    print("─" * 50)

    logger.info(
        "Order request | symbol=%s side=%s type=%s qty=%s price=%s stop=%s",
        symbol, side, order_type, qty, lmt_price, stp_price,
    )

    # --- Place order ---
    try:
        response = client.place_order(
            symbol=symbol,
            side=side,
            order_type=order_type,
            quantity=qty,
            price=lmt_price,
            stop_price=stp_price,
        )
    except BinanceAPIError as exc:
        logger.error("API error placing order: %s", exc)
        print(f"\n  ✗ FAILED — {exc}")
        raise
    except (ConnectionError, TimeoutError) as exc:
        logger.error("Network error placing order: %s", exc)
        print(f"\n  ✗ FAILED — {exc}")
        raise

    logger.info("Order placed successfully | response=%s", response)
    print(_format_response(response))
    return response
