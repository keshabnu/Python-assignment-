"""
cli.py – Command-line interface for the Binance Futures trading bot.

Usage examples:
    python -m bot.cli --symbol BTCUSDT --side BUY --type MARKET --quantity 0.01
    python -m bot.cli --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.01 --price 60000
    python -m bot.cli --symbol ETHUSDT --side BUY --type STOP_MARKET --quantity 0.1 --stop-price 3000
    python -m bot.cli --symbol BTCUSDT --side SELL --type STOP_LIMIT --quantity 0.01 --price 58000 --stop-price 59000
"""

import argparse
import os
import sys

from .client import BinanceFuturesClient, BinanceAPIError
from .logging_config import setup_logging, get_logger
from .orders import place_order
from .validators import ValidationError

logger = get_logger("cli")


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="trading-bot",
        description="Place orders on Binance Futures Testnet (USDT-M).",
        formatter_class=argparse.RawTextHelpFormatter,
        epilog=(
            "Examples:\n"
            "  Market BUY  : python -m bot.cli --symbol BTCUSDT --side BUY --type MARKET --quantity 0.01\n"
            "  Limit SELL  : python -m bot.cli --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.01 --price 60000\n"
            "  Stop-Market : python -m bot.cli --symbol ETHUSDT --side BUY --type STOP_MARKET --quantity 0.1 --stop-price 3000\n"
            "  Stop-Limit  : python -m bot.cli --symbol BTCUSDT --side SELL --type STOP_LIMIT --quantity 0.01 --price 58000 --stop-price 59000\n"
        ),
    )

    # Order parameters
    parser.add_argument(
        "--symbol", required=True,
        help="Trading pair symbol, e.g. BTCUSDT, ETHUSDT"
    )
    parser.add_argument(
        "--side", required=True, choices=["BUY", "SELL"],
        help="Order direction: BUY or SELL"
    )
    parser.add_argument(
        "--type", dest="order_type", required=True,
        choices=["MARKET", "LIMIT", "STOP_MARKET", "STOP_LIMIT"],
        help="Order type"
    )
    parser.add_argument(
        "--quantity", required=True,
        help="Order quantity (e.g. 0.01 for BTC)"
    )
    parser.add_argument(
        "--price",
        help="Limit price — required for LIMIT and STOP_LIMIT orders"
    )
    parser.add_argument(
        "--stop-price", dest="stop_price",
        help="Trigger price — required for STOP_MARKET and STOP_LIMIT orders"
    )

    # API credentials (can also be set via env vars)
    parser.add_argument(
        "--api-key", dest="api_key",
        default=os.getenv("BINANCE_API_KEY", ""),
        help="Binance Testnet API key (or set BINANCE_API_KEY env var)"
    )
    parser.add_argument(
        "--api-secret", dest="api_secret",
        default=os.getenv("BINANCE_API_SECRET", ""),
        help="Binance Testnet API secret (or set BINANCE_API_SECRET env var)"
    )

    # Misc
    parser.add_argument(
        "--log-level", dest="log_level", default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Logging verbosity (default: INFO)"
    )

    return parser


def main(argv=None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    # Set up logging first
    setup_logging(args.log_level)
    logger.info("CLI invoked with args: %s", vars(args))

    # Validate API credentials
    if not args.api_key or not args.api_secret:
        print(
            "\n  ✗ ERROR: API key and secret are required.\n"
            "  Set them via --api-key / --api-secret flags\n"
            "  or BINANCE_API_KEY / BINANCE_API_SECRET environment variables.\n"
        )
        return 1

    # Initialise client
    try:
        client = BinanceFuturesClient(
            api_key=args.api_key,
            api_secret=args.api_secret,
        )
    except ValueError as exc:
        print(f"\n  ✗ ERROR: {exc}\n")
        return 1

    # Place order
    try:
        place_order(
            client=client,
            symbol=args.symbol,
            side=args.side,
            order_type=args.order_type,
            quantity=args.quantity,
            price=args.price,
            stop_price=args.stop_price,
        )
        return 0

    except ValidationError as exc:
        logger.warning("Validation error: %s", exc)
        print(f"\n  ✗ VALIDATION ERROR: {exc}\n")
        return 2

    except BinanceAPIError as exc:
        logger.error("API error: %s", exc)
        print(f"\n  ✗ API ERROR [{exc.code}]: {exc.message}\n")
        return 3

    except (ConnectionError, TimeoutError) as exc:
        logger.error("Network error: %s", exc)
        print(f"\n  ✗ NETWORK ERROR: {exc}\n")
        return 4

    except Exception as exc:
        logger.exception("Unexpected error: %s", exc)
        print(f"\n  ✗ UNEXPECTED ERROR: {exc}\n")
        return 5


if __name__ == "__main__":
    sys.exit(main())
