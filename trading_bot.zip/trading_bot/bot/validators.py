from decimal import Decimal, InvalidOperation
from typing import Optional


VALID_ORDER_TYPES = {"MARKET", "LIMIT", "STOP_MARKET", "STOP_LIMIT"}
VALID_SIDES = {"BUY", "SELL"}


class ValidationError(ValueError):
    """Raised when user-supplied input fails validation."""


def validate_symbol(symbol: str) -> str:
    """Validate and normalise a trading symbol (e.g. BTCUSDT)."""
    symbol = symbol.strip().upper()
    if not symbol or not symbol.isalpha():
        raise ValidationError(
            f"Invalid symbol '{symbol}'. Must be alphabetic, e.g. BTCUSDT."
        )
    return symbol


def validate_side(side: str) -> str:
    """Validate order side (BUY or SELL)."""
    side = side.strip().upper()
    if side not in VALID_SIDES:
        raise ValidationError(
            f"Invalid side '{side}'. Must be one of: {', '.join(sorted(VALID_SIDES))}."
        )
    return side


def validate_order_type(order_type: str) -> str:
    """Validate order type."""
    order_type = order_type.strip().upper()
    if order_type not in VALID_ORDER_TYPES:
        raise ValidationError(
            f"Invalid order type '{order_type}'. "
            f"Must be one of: {', '.join(sorted(VALID_ORDER_TYPES))}."
        )
    return order_type


def validate_quantity(quantity: str) -> Decimal:
    """Validate quantity – must be a positive number."""
    try:
        qty = Decimal(str(quantity))
    except InvalidOperation:
        raise ValidationError(f"Invalid quantity '{quantity}'. Must be a number.")
    if qty <= 0:
        raise ValidationError(f"Quantity must be greater than zero, got {qty}.")
    return qty


def validate_price(price: Optional[str], order_type: str) -> Optional[Decimal]:
    """Validate price – required for LIMIT / STOP_LIMIT orders."""
    if order_type in {"LIMIT", "STOP_LIMIT"}:
        if price is None:
            raise ValidationError(
                f"Price is required for {order_type} orders."
            )
        try:
            p = Decimal(str(price))
        except InvalidOperation:
            raise ValidationError(f"Invalid price '{price}'. Must be a number.")
        if p <= 0:
            raise ValidationError(f"Price must be greater than zero, got {p}.")
        return p
    return None


def validate_stop_price(stop_price: Optional[str], order_type: str) -> Optional[Decimal]:
    """Validate stop price – required for STOP_MARKET and STOP_LIMIT orders."""
    if order_type in {"STOP_MARKET", "STOP_LIMIT"}:
        if stop_price is None:
            raise ValidationError(
                f"Stop price is required for {order_type} orders."
            )
        try:
            sp = Decimal(str(stop_price))
        except InvalidOperation:
            raise ValidationError(f"Invalid stop price '{stop_price}'. Must be a number.")
        if sp <= 0:
            raise ValidationError(f"Stop price must be greater than zero, got {sp}.")
        return sp
    return None
