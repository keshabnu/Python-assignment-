# Binance Futures Testnet Trading Bot

A lightweight Python CLI application for placing orders on the **Binance Futures Testnet (USDT-M)**. Built with a clean layered architecture, structured logging, and robust error handling.

---

## Project Structure

```
trading_bot/
├── bot/
│   ├── __init__.py
│   ├── client.py          # Binance REST API client (signing, HTTP)
│   ├── orders.py          # Order placement logic & output formatting
│   ├── validators.py      # Input validation layer
│   ├── logging_config.py  # Logging setup (file + console)
│   └── cli.py             # CLI entry point (argparse)
├── logs/
│   └── trading_bot.log    # Auto-created on first run
├── README.md
└── requirements.txt
```

---

## Setup

### 1. Prerequisites

- Python 3.8+
- pip

### 2. Get Binance Futures Testnet Credentials

1. Go to [https://testnet.binancefuture.com](https://testnet.binancefuture.com)
2. Log in with your GitHub account
3. Click **API Keys** → generate a new key pair
4. Copy your **API Key** and **Secret Key**

### 3. Install Dependencies

```bash
cd trading_bot
pip install -r requirements.txt
```

### 4. Set API Credentials

You can provide credentials either as environment variables (recommended) or as CLI flags.

**Option A – Environment variables (recommended):**
```bash
export BINANCE_API_KEY="your_api_key_here"
export BINANCE_API_SECRET="your_api_secret_here"
```

**Option B – Inline flags (not recommended for production):**
```bash
python -m bot.cli --api-key YOUR_KEY --api-secret YOUR_SECRET ...
```

---

## How to Run

Run all commands from the `trading_bot/` directory.

### Market Order (BUY)

```bash
python -m bot.cli --symbol BTCUSDT --side BUY --type MARKET --quantity 0.01
```

### Market Order (SELL)

```bash
python -m bot.cli --symbol BTCUSDT --side SELL --type MARKET --quantity 0.01
```

### Limit Order (BUY)

```bash
python -m bot.cli --symbol BTCUSDT --side BUY --type LIMIT --quantity 0.01 --price 95000
```

### Limit Order (SELL)

```bash
python -m bot.cli --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.01 --price 105000
```

### Stop-Market Order (Bonus)

```bash
python -m bot.cli --symbol ETHUSDT --side BUY --type STOP_MARKET --quantity 0.1 --stop-price 3000
```

### Stop-Limit Order (Bonus)

```bash
python -m bot.cli --symbol BTCUSDT --side SELL --type STOP_LIMIT --quantity 0.01 --price 58000 --stop-price 59000
```

### Help

```bash
python -m bot.cli --help
```

---

## Sample Output

```
──────────────────────────────────────────────────
  ORDER REQUEST SUMMARY
──────────────────────────────────────────────────
  Symbol     : BTCUSDT
  Side       : BUY
  Type       : MARKET
  Quantity   : 0.01
──────────────────────────────────────────────────

──────────────────────────────────────────────────
  ORDER PLACED SUCCESSFULLY
──────────────────────────────────────────────────
  Order ID   : 4265880820
  Symbol     : BTCUSDT
  Side       : BUY
  Type       : MARKET
  Status     : FILLED
  Quantity   : 0.01
  Executed   : 0.01
  Avg Price  : 103412.40
──────────────────────────────────────────────────
```

---

## Logging

All activity is logged to `logs/trading_bot.log` with rotating file support (max 5 MB, 3 backups).

Log levels:
- **INFO** – API requests, responses, order lifecycle events
- **WARNING** – Validation errors
- **ERROR** – API errors, network failures, unexpected exceptions

Adjust verbosity with `--log-level DEBUG|INFO|WARNING|ERROR`.

---

## Error Handling

| Scenario | Behaviour |
|---|---|
| Missing required field (e.g. price for LIMIT) | Validation error printed, exit code 2 |
| Invalid side / symbol / quantity | Validation error printed, exit code 2 |
| Binance API error (e.g. insufficient margin) | API error code + message printed, exit code 3 |
| Network / connection failure | Clear network error message, exit code 4 |
| Missing API credentials | Prompt to set env vars or flags, exit code 1 |

---

## Assumptions

- The bot targets **USDT-M Perpetual Futures** on the Binance Testnet only.
- `timeInForce` defaults to `GTC` (Good Till Cancelled) for LIMIT orders.
- Quantity precision must match the symbol's filter on the exchange — use small values like `0.01` for BTCUSDT on testnet to avoid `LOT_SIZE` errors.
- API credentials are **not** stored or committed — always use environment variables.
- The `logs/` directory is created automatically on first run.

---

## Requirements

```
requests>=2.31.0
```
